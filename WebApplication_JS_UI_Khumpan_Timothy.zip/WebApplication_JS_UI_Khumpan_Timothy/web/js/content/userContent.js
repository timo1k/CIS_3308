
"use strict"; // update soln sp 23

function userContent() {
    
    function deleteUser(origObj, clickedTd) {

        var userId = origObj.webUserId;
        console.log("To delete user " + userId + "?");

        // Since you have the whole webUser object passed in (origObj), give a better 
        // indication of the webUser that you are asking about (to delete? deleted?) - better
        // than just an id. 

        if (confirm("Do you really want to delete user " + userId + "? ")) {

           var url = "http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/user/delete.jsp?deleteId=" + userId;         

            console.log("onclick function will make AJAX call with url: " + url);
            
            ajax(url, processDelete, origObj);
            
            function processDelete(obj) {
                if (obj.errorMsg.length === 0) { // success
                    var dataRow = clickedTd.parentNode;
                    var rowIndex = dataRow.rowIndex - 1; // adjust for oolumn header row?
                    var dataTable = dataRow.parentNode;
                    dataTable.deleteRow(rowIndex);
                    alert("SUCCESFULLY DELETED WEB USER RECORD!");
                } 
                else {
                    
                    if (obj.errorMsg.includes("REFERENCES")) {
                        alert("You cannot delete this user because he or she has posts. (FK is Ref. this PK)");
                    }
                    else{
                        alert(obj.errorMsg);
                    }
                }           
            };

        }
    } // deleteUser
    
    function makeNewObj(origObj) {
        
        var newObj = {};
        
        newObj.User_Id = SortableTableUtils.makeNumber(origObj.webUserId, false);

        newObj.User_Credentials = SortableTableUtils.makeText(origObj.userEmail +
                "<span style='font-size:0.7rem'><br/>Test Logon with this PW:<br/></span>" +
                origObj.userPassword);
        newObj.User_Credentials.style.textAlign = "center";
        newObj.User_Credentials.style.lineHeight = "1.25rem";

        // last parameter true means add shadow to the image
        newObj.Image = SortableTableUtils.makeImage(origObj.image, "5rem", true);
        var img = newObj.Image.getElementsByTagName("img")[0];
        img.classList.add("shadow");

        newObj.Birthday = SortableTableUtils.makeDate(origObj.birthday);
        newObj.Membership_Fee = SortableTableUtils.makeNumber(origObj.membershipFee, true);
        newObj.Role = SortableTableUtils.makeText(origObj.userRoleId + "&nbsp;" +
                origObj.userRoleType);
        newObj.Update = SortableTableUtils.makeIconLink(
                "icons/update.png", // iconFile
                "width:1rem",       // iconStyle
                '#/userUpdate/' + origObj.webUserId); // href


        newObj.Delete = SortableTableUtils.makeImage("icons/delete.png", '1rem');

        newObj.Delete.onclick = function () {
        deleteUser(origObj, this); // "this" means the <td> that was clicked. 
        };
        return newObj;
    }

    var contentDOM = document.createElement("div");
    contentDOM.classList.add("clickSort");
    ajax("webAPIs/user/getAll.jsp", success, contentDOM);
    function success(obj) {

        console.log("listUsersAPI.jsp AJAX successfully returned the following data");
        console.log(obj);

        // Remember: getting a successful ajax call does not mean you got data. 
        // There could have been a DB error (like DB unavailable). 
        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var heading = Utils.make({
            htmlTag: "h2",
            parent: contentDOM
        });
        Utils.make({// don't need reference to this span tag...
            htmlTag: "span",
            innerHTML: "Web User List ",
            parent: heading
        });
        var img = Utils.make({
            htmlTag: "img",
            parent: heading
        });
        img.src = "icons/insert.jpeg";
        img.style.width = "3rem";
        img.onclick = function () {
            // By changing the URL, you invoke the user insert. 
            window.location.hash = "#/userInsert";
        };


        /* Property names in Web APIs for web_user data: "webUserId", "userEmail", "userPassword", "userPassword2", 
         * "image", "birthday", "membershipFee", "userRoleId", "userRoleType", "errorMsg"   */

        // create userList (new array of objects) to have only the desired properties of obj.webUserList. 
        // Add the properties in the order you want them to appear in the HTML table.  
        
        var userList = [];
        for (var webUserObj of obj.webUserList) {
            userList.push(makeNewObj(webUserObj));
        }

        console.log("heading in liveUserContent on next line");
        console.log(heading);

        var webUserTable = MakeClickSortTable({
            objList: userList,
            //initialSortCol: "Birthday", // if not provided, sort will be by the first column.
            sortIcon: "icons/sortUpDown16.png"
        });

        contentDOM.appendChild(webUserTable);
    } // end of function success

    return contentDOM;
} // liveUserContent