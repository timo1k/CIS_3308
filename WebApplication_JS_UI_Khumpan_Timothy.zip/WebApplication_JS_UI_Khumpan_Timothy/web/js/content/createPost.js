"use strict";
function createPost() {
    var obj = document.createElement("div");
    obj.innerHTML=`
    <table>
                    <tr>
                        <td>Anime Name</td>
                        <td><input type="text"  id="animeName" /></td>
                        <td id="animeNameError" class="error"></td> 
                    </tr>
                    <tr>
                        <td>Anime Japanese Name</td>
                        <td><input type="text"  id="animeJapaneseName" /></td>
                        <td id="animeJapaneseNameError" class="error"></td>
                    </tr>
                   
                    <tr>
                        <td>Anime Image URL</td>
                        <td><input type="text" id="animeImg" /></td>
                        <td id="animeImgError" class="error"></td>
                    </tr>
                    <tr>
                        <td>Watch Date</td>
                        <td><input type="text" id="watchDate" /></td>
                        <td id="watchDateError" class="error"></td> 
                    </tr>
                    <tr>
                        <td>Anime Rating</td>
                        <td><input type="text" id="animeRating" /></td>
                        <td id="animeRatingError" class="error"></td>
                    </tr>
                     <tr>
                        <td>Anime Desc</td>
                        <td><input type="text" id="animeDesc" /></td>
                        <td id="animeDescError" class="error"></td>
                    </tr>
                    <tr>
                        <td>Web User Id</td>
                        <td><input type="text" id="webUserId" /></td>
                        <td id="webUserIdError" class="error"></td>
                    </tr>
                    <tr>
                        <td><button onclick="insertSave()">Save</button></td>
                        <td id="recordError" class="error"></td>
                        <td></td>
                    </tr>
    </table>

    `;
    obj.classList.add("insertArea");
    
    
    return obj;
    
}

function insertSave() {
    console.log("insertSave was called");

    // create a user object from the values that the user has typed into the page.
    var userInputObj = {
        "animeId": "",
        "animeName": document.getElementById("animeName").value,
        "animeJapaneseName": document.getElementById("animeJapaneseName").value,
        "animeImg": document.getElementById("animeImg").value,
        "watchDate": document.getElementById("watchDate").value,
        "animeRating": document.getElementById("animeRating").value,
        "animeDesc": document.getElementById("animeDesc").value,
        "webUserId": document.getElementById("webUserId").value,
        "userEmail": "",
        "errorMsg": ""
    };
    console.log(userInputObj);

    // build the url for the ajax call. Remember to encodeURI the user input object or else 
    // you may get a security error from the server. JSON.stringify converts the javaScript
    // object into JSON format (the reverse operation of what gson does on the server side).
    var myData = encodeURI(JSON.stringify(userInputObj));
    var url = "webAPIs/insertOtherAPI.jsp?jsonData=" + myData;
    ajax(url, insertAPISuccess, document.getElementById("recordError"));

    function insertAPISuccess(jsObj) {
        // Running this function does not mean insert success. It just means that the Web API
        // call (to insert the record) was successful.
        // 
        // the server prints out a JSON string of an object that holds field level error 
        // messages. The error message object (conveniently) has its fiels named exactly 
        // the same as the input data was named. 
        console.log("here is JSON object (holds error messages.");
        console.log(jsObj);

        document.getElementById("animeNameError").innerHTML = jsObj.animeName;
        document.getElementById("animeJapaneseNameError").innerHTML = jsObj.animeJapaneseName;

        document.getElementById("animeImgError").innerHTML = jsObj.animeImg;
        document.getElementById("watchDateError").innerHTML = jsObj.watchDate;
        document.getElementById("animeRatingError").innerHTML = jsObj.animeRating;
        document.getElementById("animeDescError").innerHTML = jsObj.animeDesc;
        document.getElementById("webUserIdError").innerHTML = jsObj.webUserId;

        if (jsObj.errorMsg.length === 0) { // success
            jsObj.errorMsg = "Record successfully inserted !!!";
        }
        document.getElementById("recordError").innerHTML = jsObj.errorMsg;
    }
}
