var account = {}; // Declare account before the IIFE so it is global.

(function () { // This is an IIFE immediately invoking function execution
    
    account.logon = function ( ) { // public method of global object
        var logOnDiv = document.createElement("div");
        logOnDiv.classList.add("logOn");

        var userInput = document.createElement("input");
        var userPass = document.createElement("input");

        var content = document.createElement('span');
        content.innerHTML = "Email Address:";
        logOnDiv.appendChild(content);
        logOnDiv.appendChild(userInput);

        var content1 = document.createElement('span');
        content1.innerHTML = "Password: ";
        content1.setAttribute("type", "password");
        logOnDiv.appendChild(content1);
        logOnDiv.appendChild(userPass);

        var findButton = document.createElement("button");
        findButton.innerHTML = "Submit";
        logOnDiv.appendChild(findButton);

        var msgDiv = document.createElement("div");
        logOnDiv.appendChild(msgDiv);
        
        findButton.onclick = function () {

        // You have to encodeURI user input before putting into a URL for an AJAX call.
        // Otherwise, your URL may be refused (for security reasons) by the web server.
        
        //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/logonAPI.jsp
        //webAPIs/logonAPI.jsp?email=
        //http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/listUsersAPI.jsp
            var url = "http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/logonAPI.jsp?email=" + escape(userInput.value) +
              "&password=" + escape(userPass.value);         

            console.log("onclick function will make AJAX call with url: " + url);
            ajax(url, processLogon, msgDiv);
            
            function processLogon(obj) {
                msgDiv.innerHTML = buildProfile(obj);
            };
        };
        return logOnDiv;
    };
    
    function buildProfile(obj) { // NOW PRIVATE, can be called by any of the account functions…
        
        var msg = "";
        console.log("Successfully called the find API. Next line shows the returned object.");
        console.log(obj);
        if (obj.errorMsg.length > 0) {
            msg += "<strong>Error: " + obj.errorMsg + "</strong>";
        } 
        else {
            msg += "<strong>Welcome Web User " + obj.webUserId + "</strong>";
            msg += "<br/> Birthday: " + obj.birthday;
            msg += "<br/> MembershipFee: " + obj.membershipFee;
            msg += "<br/> User Role: " + obj.userRoleId + " " + obj.userRoleType;
            msg += "<p> <img src ='" + obj.image + "'></p>";
        }
        return msg;
    };
    
    account.getProfile = function ( ) {
        // create a div, invoke Get Profile API, fill div w/ error msg or web user info, return the div.
        var logOnDiv = document.createElement("div");
        logOnDiv.classList.add("logOn");
        
       
        var msgDiv = document.createElement("div");
        logOnDiv.appendChild(msgDiv);
        //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/getProfileAPI.jsp
        //http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/
        var url = "http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/getProfileAPI.jsp";
        ajax(url, processLogon, msgDiv);
        function processLogon(obj) {
            msgDiv.innerHTML = buildProfile(obj);
        };
        
        return logOnDiv;
    };
    
    account.logoff = function ( ) {
        // create a div, invoke logoff API, fill div with “logged off” message, return the div.
        var logOnDiv = document.createElement("div");
        logOnDiv.classList.add("logOn");
        var msgDiv = document.createElement("div");
        logOnDiv.appendChild(msgDiv);
        //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/getProfileAPI.jsp
        //http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/
        var url = "http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/logoffAPI.jsp";
        
        ajax(url, processLogon, msgDiv);
        function processLogon(obj) {
            var msg = "";
            if (obj.errorMsg.length > 0) {
                msg += "<strong>You Have Logged Out! " + obj.errorMsg + "</strong>";
            } 
            else {
                msg += "<strong>You Have Logged Out! " + obj.errorMsg + "</strong>";
            }
            msgDiv.innerHTML = msg;
        }
        return logOnDiv;
        
    };
    
})();