
"use strict"; // update soln sp 23

function otherContent() {
    
    function deleteAnime(origObj, clickedTd) {

        var animeId = origObj.animeId;
        console.log("To delete anime record " + animeId + "?");

        // Since you have the whole webUser object passed in (origObj), give a better 
        // indication of the webUser that you are asking about (to delete? deleted?) - better
        // than just an id. 

        if (confirm("Do you really want to delete anime record " + animeId + "? ")) {
                   
           var url = "http://cis-linux2.temple.edu:8080/sp23_3308_tuk21567/webAPIs/anime/deleteAnime.jsp?deleteId=" + animeId;         

            console.log("onclick function will make AJAX call with url: " + url);
            
            ajax(url, processDelete, origObj);
            
            function processDelete(obj) {
                if (obj.errorMsg.length === 0) { // success
                    var dataRow = clickedTd.parentNode;
                    var rowIndex = dataRow.rowIndex - 1; // adjust for oolumn header row?
                    var dataTable = dataRow.parentNode;
                    dataTable.deleteRow(rowIndex);
                    alert("SUCCESFULLY DELETED ANIME RECORD!");
                } 
                else {
                    
                    if (obj.errorMsg.includes("REFERENCES")) {
                        alert("You cannot delete this anime record because a FK is Ref. this PK");
                    }
                    else{
                        alert(obj.errorMsg);
                    }
                }           
            };

        }
    } // deleteAnime
    
    function makeNewObj(origObj) {
        
        var newObj = {};
        
        newObj.Anime_Id = SortableTableUtils.makeNumber(origObj.animeId, false);

        newObj.Anime_Name = SortableTableUtils.makeText(origObj.animeName);
        newObj.Anime_Japanese_Name = SortableTableUtils.makeText(origObj.animeJapaneseName);


        // last parameter true means add shadow to the image
        newObj.Anime_Img = SortableTableUtils.makeImage(origObj.animeImg, "5rem", true);
        var img = newObj.Anime_Img.getElementsByTagName("img")[0];
        img.classList.add("shadow");

        newObj.Watch_Date = SortableTableUtils.makeDate(origObj.watchDate);
        newObj.Anime_Rating = SortableTableUtils.makeNumber(origObj.animeRating, false);
        newObj.Anime_Desc = SortableTableUtils.makeText(origObj.animeDesc);

        newObj.Web_User_Id = SortableTableUtils.makeText(origObj.webUserId + "&nbsp;" +
                origObj.userEmail);
        newObj.Update = SortableTableUtils.makeIconLink(
                "icons/update.png", // iconFile
                "width:1rem",       // iconStyle
                '#/otherUpdate/' + origObj.animeId); // href

        newObj.Delete = SortableTableUtils.makeImage("icons/delete.png", '1rem');

        newObj.Delete.onclick = function () {
        deleteAnime(origObj, this); // "this" means the <td> that was clicked. 
        };
        
        return newObj;
    }

    var contentDOM = document.createElement("div");
    contentDOM.classList.add("clickSort");
    ajax("webAPIs/anime/getOtherAll.jsp", success, contentDOM);
    function success(obj) {

        console.log("listOtherAPI.jsp AJAX successfully returned the following data");
        console.log(obj);

        // Remember: getting a successful ajax call does not mean you got data. 
        // There could have been a DB error (like DB unavailable). 
        if (obj.dbError.length > 0) {
            contentDOM.innerHTML += "Database Error Encountered: " + obj.dbError;
            return;
        }

        var heading = Utils.make({
            htmlTag: "h2",
            parent: contentDOM
        });
        Utils.make({// don't need reference to this span tag...
            htmlTag: "span",
            innerHTML: "Anime List ",
            parent: heading
        });
        var img = Utils.make({
            htmlTag: "img",
            parent: heading
        });
        img.src = "icons/insert.jpeg";
        img.style.width = "3rem";
        img.onclick = function () {
            // By changing the URL, you invoke the user insert. 
            window.location.hash = "#/otherInsert";
        };

        var animeList = [];
        for (var animeObj of obj.animeList) {
            animeList.push(makeNewObj(animeObj));
        }

        console.log("heading in liveOtherContent on next line");
        console.log(heading);

        var animeTable = MakeClickSortTable({
            objList: animeList,
            //initialSortCol: "Birthday", // if not provided, sort will be by the first column.
            sortIcon: "icons/sortUpDown16.png"
        });

        contentDOM.appendChild(animeTable);
    } // end of function success

    return contentDOM;
} // liveUserContent