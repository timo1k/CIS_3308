function logOn() {

    var logOnDiv = document.createElement("div");
    logOnDiv.classList.add("logOn");

    var title = document.createElement('div');
    title.innerHTML = "<strong>Logon:</strong>";
    logOnDiv.appendChild(title);
    
    var userInput = document.createElement("input");
    var userPass = document.createElement("input");
    
    var content = document.createElement('span');
    content.innerHTML = "Email Address:";
    logOnDiv.appendChild(content);
    logOnDiv.appendChild(userInput);
    
    var content1 = document.createElement('span');
    content1.innerHTML = "Password: ";
    logOnDiv.appendChild(content1);
    logOnDiv.appendChild(userPass);

    var findButton = document.createElement("button");
    findButton.innerHTML = "Submit";
    logOnDiv.appendChild(findButton);

    var msgDiv = document.createElement("div");
    logOnDiv.appendChild(msgDiv);

    findButton.onclick = function () {

        // You have to encodeURI user input before putting into a URL for an AJAX call.
        // Otherwise, your URL may be refused (for security reasons) by the web server.
        
        //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/logonAPI.jsp
        //webAPIs/logonAPI.jsp?email=
        var url = "http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/logonAPI.jsp?email=" + escape(userInput.value) +
              "&password=" + escape(userPass.value);         

        console.log("onclick function will make AJAX call with url: " + url);
        ajax(url, processLogon, msgDiv);

        function processLogon(obj) {
            var msg = "";
            console.log("Successfully called the find API. Next line shows the returned object.");
            console.log(obj);
            if (obj.errorMsg.length > 0) {
                msg += "<strong>Error: " + obj.errorMsg + "</strong>";
            } else {
                msg += "<strong>Welcome Web User " + obj.webUserId + "</strong>";
                msg += "<br/> Birthday: " + obj.birthday;
                msg += "<br/> MembershipFee: " + obj.membershipFee;
                msg += "<br/> User Role: " + obj.userRoleId + " " + obj.userRoleType;
                msg += "<p> <img src ='" + obj.image + "'></p>";
            }
            msgDiv.innerHTML = msg;
        }
    };  // onclick function

    return logOnDiv;
};

