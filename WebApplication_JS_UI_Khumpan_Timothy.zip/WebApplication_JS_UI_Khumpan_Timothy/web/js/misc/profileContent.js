function profileContent() {

    var logOnDiv = document.createElement("div");
    logOnDiv.classList.add("logOn");

    var title = document.createElement('div');
    title.innerHTML = "<strong>Profile:</strong>";
    logOnDiv.appendChild(title);

    var msgDiv = document.createElement("div");
    logOnDiv.appendChild(msgDiv);
    
    //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/getProfileAPI.jsp
    var url = "http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/getProfileAPI.jsp"; 
      
    ajax(url, processLogon, msgDiv);
    
    function processLogon(obj) {
            var msg = "";
            if (obj.errorMsg.length > 0) {
                msg += "<strong>Error: " + obj.errorMsg + "</strong>";
            } else {
                msg += "<strong>Welcome Web User " + obj.webUserId + "</strong>";
                msg += "<br/> Birthday: " + obj.birthday;
                msg += "<br/> MembershipFee: " + obj.membershipFee;
                msg += "<br/> User Role: " + obj.userRoleId + " " + obj.userRoleType;
                msg += "<p> <img src ='" + obj.image + "'></p>";
            }
            msgDiv.innerHTML = msg;
        }

    return logOnDiv;
};

