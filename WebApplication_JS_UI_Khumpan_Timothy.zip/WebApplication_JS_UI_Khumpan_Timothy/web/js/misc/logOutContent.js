function logOutContent() {

    var logOnDiv = document.createElement("div");
    logOnDiv.classList.add("logOn");

    var msgDiv = document.createElement("div");
    logOnDiv.appendChild(msgDiv);
    
    //http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/getProfileAPI.jsp
    var url = "http://localhost:8080/WebApplication_JS_UI_Khumpan_Timothy/webAPIs/logoffAPI.jsp"; 
      
    ajax(url, processLogon, msgDiv);
    
    function processLogon(obj) {
            var msg = "";
            if (obj.errorMsg.length > 0) {
                msg += "<strong>You Have Logged Out! " + obj.errorMsg + "</strong>";
            } else {
                msg += "<strong>You Have Logged Out! " + obj.errorMsg + "</strong>";
            }
            msgDiv.innerHTML = msg;
        }

    return logOnDiv;
};
