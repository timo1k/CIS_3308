package model.anime;

import dbUtils.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbMods {
    
    public static String delete (String animeId, DbConn dbc) {

        if (animeId == null) {
            return "Error in model.anime.DbMods.delete: cannot delete anime record because 'animeId' is null";
        }

        // This method assumes that the calling Web API (JSP page) has already confirmed 
        // that the database connection is OK. BUT if not, some reasonable exception should 
        // be thrown by the DB and passed back anyway... 
        String result = ""; // empty string result means the delete worked fine.
        try {

            String sql = "DELETE FROM anime WHERE anime_id = ?";

            // This line compiles the SQL statement (checking for syntax errors against your DB).
            PreparedStatement pStatement = dbc.getConn().prepareStatement(sql);
            //PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encode user data into the prepared statement.
            pStatement.setString(1, animeId);

            int numRowsDeleted = pStatement.executeUpdate();

            if (numRowsDeleted == 0) {
                result = "Record not deleted - there was no record with anime_id " + animeId;
            } else if (numRowsDeleted > 1) {
                result = "Programmer Error: > 1 record deleted. Did you forget the WHERE clause?";
            }

        } catch (Exception e) {
            result = "Exception thrown in model.anime.DbMods.delete(): " + e.getMessage();
        }

        return result;
    }
    
    public static StringData update(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

            /*
                String sql = "SELECT anime_id, anime_name, anime_japanese_name, anime_img, watch_date, anime_rating, anime_desc, anime.web_user_id, web_user.user_email "
                    + "FROM anime, web_user "
                    + "Where anime.web_user_id = web_user.web_user_id "
                    + "AND anime_id = ?";
             */
            String sql = "UPDATE anime SET anime_name=?, anime_japanese_name=?, anime_img= ?, watch_date=?, anime_rating=?, anime_desc=?, web_user_id=? "
                    + "WHERE anime_id = ?";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);
            
            //"animeId": "16",
            //"animeName": "JoJo's Bizarre Adventure",
            //"animeJapaneseName": "",
            //"animeImg": "jojo.jpg",   
            //"watchDate": "",
            //"animeRating": "",
            //"animeDesc": "",  
            //"webUserId": "14",
            //"userEmail": "elijahbigham@gmail.com",
            //"errorMsg": ""


            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, inputData.animeName); // string type is simple
            pStatement.setString(2, inputData.animeJapaneseName);
            pStatement.setString(3, inputData.animeImg);
          
            pStatement.setDate(4, ValidationUtils.dateConversion(inputData.watchDate));
            pStatement.setInt(5, ValidationUtils.integerConversion(inputData.animeRating));
            pStatement.setString(6, inputData.animeDesc);
            pStatement.setInt(7, ValidationUtils.integerConversion(inputData.webUserId));
            pStatement.setInt(8, ValidationUtils.integerConversion(inputData.animeId));

            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were updated (expected to update one record).";
                }
            } else if (errorMsgs.errorMsg.contains("foreign key")) {
                errorMsgs.errorMsg = "Invalid Web User Id";
            } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That img url is already taken";
            }
        } 
        return errorMsgs;
    } // update
    
    public static StringData findById(DbConn dbc, String id) {

        // The find API needs to represent three cases: found web_user, not found, db error. 
        model.anime.StringData sd = new model.anime.StringData();
        try {
            String sql = "SELECT anime_id, anime_name, anime_japanese_name, anime_img, watch_date, anime_rating, anime_desc, anime.web_user_id, web_user.user_email "
                    + "FROM anime, web_user "
                    + "Where anime.web_user_id = web_user.web_user_id "
                    + "AND anime_id = ?";

            PreparedStatement stmt = dbc.getConn().prepareStatement(sql);

            // Encode the id (that the user typed in) into the select statement, into the first (and only) ? 
            stmt.setString(1, id);

            ResultSet results = stmt.executeQuery();
            if (results.next()) { // id is unique, one or zero records expected in result set

                // plainInteger returns integer converted to string with no commas.
                sd.animeName = FormatUtils.formatString(results.getObject("anime_name"));
                sd.animeId = FormatUtils.plainInteger(results.getObject("anime_id"));
                sd.animeJapaneseName = FormatUtils.formatString(results.getObject("anime_japanese_name"));
                sd.animeImg = FormatUtils.formatString(results.getObject("anime_img"));
                sd.watchDate = FormatUtils.formatDate(results.getObject("watch_date"));
                sd.animeRating = FormatUtils.plainInteger(results.getObject("anime_rating"));
                sd.animeDesc = FormatUtils.formatString(results.getObject("anime_desc"));
                sd.webUserId = FormatUtils.plainInteger(results.getObject("web_user_id"));
                sd.userEmail = FormatUtils.formatString(results.getObject("user_email"));
            } else {
                sd.errorMsg = "Anime Id Not Found.";
            }
            results.close();
            stmt.close();
        } catch (Exception e) {
            sd.errorMsg = "Exception thrown in DbMods.findById(): " + e.getMessage();
        }
        return sd;

    } // findById

    /*
    Returns a "StringData" object that is full of field level validation
    error messages (or it is full of all empty strings if inputData
    totally passed validation.  
     */
    private static StringData validate(StringData inputData) {

        StringData errorMsgs = new StringData();

        /* Useful to copy field names from StringData as a reference
    public String animeId = "";
    public String animeName = "";
    public String animeJapaneseName = "";
    public String animeImg = "";
    public String watchDate = "";
    public String animeRating = "";
    public String animeDesc = "";
        
    public String webUserId = "";  // Foreign Key
    public String userEmail = "";
         */
        // Validation
        errorMsgs.animeName = ValidationUtils.stringValidationMsg(inputData.animeName, 45, true);
        errorMsgs.animeJapaneseName = ValidationUtils.stringValidationMsg(inputData.animeName, 45, false);
        errorMsgs.animeImg = ValidationUtils.stringValidationMsg(inputData.animeImg, 300, true);
        errorMsgs.watchDate = ValidationUtils.dateValidationMsg(inputData.watchDate, false);
       
        errorMsgs.animeRating = ValidationUtils.integerValidationMsg(inputData.animeRating, false);
        errorMsgs.animeDesc = ValidationUtils.stringValidationMsg(inputData.animeDesc, 250, false);

        errorMsgs.webUserId = ValidationUtils.integerValidationMsg(inputData.webUserId, true);

        return errorMsgs;
    } // validate 

    public static StringData insert(StringData inputData, DbConn dbc) {

        StringData errorMsgs = new StringData();
        errorMsgs = validate(inputData);
        if (errorMsgs.getCharacterCount() > 0) {  // at least one field has an error, don't go any further.
            errorMsgs.errorMsg = "Please try again";
            return errorMsgs;

        } else { // all fields passed validation

            /*
                  String sql = "SELECT anime_id, anime_name, anime_japanese_name, anime_img, watch_date, anime_rating, anime_desc, anime.web_user_id, web_user.user_email "
                    + "FROM anime, web_user "
                    + "Where anime.web_user_id = web_user.web_user_id "
                    + "ORDER BY anime_id ";  
             */
            // Start preparing SQL statement
            String sql = "INSERT INTO anime (anime_name, anime_japanese_name, anime_img, watch_date, anime_rating, anime_desc, web_user_id) "
                    + "VALUES (?,?,?,?,?,?,?)";

            // PrepStatement is Sally's wrapper class for java.sql.PreparedStatement
            // Only difference is that Sally's class takes care of encoding null 
            // when necessary. And it also System.out.prints exception error messages.
            PrepStatement pStatement = new PrepStatement(dbc, sql);

            // Encode string values into the prepared statement (wrapper class).
            pStatement.setString(1, inputData.animeName); // string type is simple
            pStatement.setString(2, inputData.animeJapaneseName);
            pStatement.setString(3, inputData.animeImg);
            pStatement.setDate(4, ValidationUtils.dateConversion(inputData.watchDate));
            pStatement.setInt(5, ValidationUtils.integerConversion(inputData.animeRating));
            pStatement.setString(6, inputData.animeDesc);
            pStatement.setInt(7, ValidationUtils.integerConversion(inputData.webUserId));

            // here the SQL statement is actually executed
            int numRows = pStatement.executeUpdate();

            // This will return empty string if all went well, else all error messages.
            errorMsgs.errorMsg = pStatement.getErrorMsg();
            if (errorMsgs.errorMsg.length() == 0) {
                if (numRows == 1) {
                    errorMsgs.errorMsg = ""; // This means SUCCESS. Let the user interface decide how to tell this to the user.
                } else {
                    // probably never get here unless you forgot your WHERE clause and did a bulk sql update.
                    errorMsgs.errorMsg = numRows + " records were inserted when exactly 1 was expected.";
                }
            } else if (errorMsgs.errorMsg.contains("foreign key")) {
                errorMsgs.errorMsg = "Invalid Web User Id";
            } else if (errorMsgs.errorMsg.contains("Duplicate entry")) {
                errorMsgs.errorMsg = "That img url is already taken";
            }

        } 
        return errorMsgs;
    } // insert

} // class
